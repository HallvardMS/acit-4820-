import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64 # CHANGED: Import Float64

class KeyboardWrenchController(Node):
    def __init__(self):
        super().__init__('keyboard_wrench_controller')
        # CHANGED: Publish Float64 to a topic like /cmd_thrust
        self.pub = self.create_publisher(Float64, 'cmd_thrust', 10)

        # This is now Propeller Speed (rad/s) or duty cycle, NOT Newtons directly
        self.command_value = float(self.declare_parameter('force', 5.0).get_parameter_value().double_value)
        
        rate = int(self.declare_parameter('rate', 10).get_parameter_value().integer_value)
        self.timer = self.create_timer(1.0 / rate, self.update)

    def update(self):
        msg = Float64()
        msg.data = self.command_value # CHANGED: Just assign the float value
        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = KeyboardWrenchController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        # Only shut down if rclpy is still active
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()